# Bob's IPTV

A simple Android TV IPTV player (Kotlin, Jetpack Compose, Media3/ExoPlayer).
It plays playlists you provide (M3U/M3U8). It ships with a free public English playlist from iptv-org.

## Remote controls
- OK on a channel: preview it. OK again: fullscreen.
- Fullscreen: Up/Down (or CH+/CH-) to change channel, OK to show info, Back to exit.
- Hold OK (or press Menu) on a channel: toggle favorite.
- Gear chip at the end of the category row: change playlist URL.

## Build
Pushing to GitHub runs `.github/workflows/build.yml`, which builds the APK.
Download it from the repo's Releases page (tag "latest") or the Actions run's artifacts.
