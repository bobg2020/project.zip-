package com.bobs.iptv

import android.content.Context

/** Free, public English channels maintained by the iptv-org community. Change it in the app's settings. */
const val DEFAULT_PLAYLIST = "https://iptv-org.github.io/iptv/languages/eng.m3u"

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("bobs_iptv", Context.MODE_PRIVATE)

    var playlistUrl: String
        get() = sp.getString("playlist_url", DEFAULT_PLAYLIST) ?: DEFAULT_PLAYLIST
        set(v) = sp.edit().putString("playlist_url", v).apply()

    var favorites: Set<String>
        get() = HashSet(sp.getStringSet("favorites", emptySet()) ?: emptySet())
        set(v) = sp.edit().putStringSet("favorites", HashSet(v)).apply()

    var lastChannel: String?
        get() = sp.getString("last_channel", null)
        set(v) = sp.edit().putString("last_channel", v).apply()
}
