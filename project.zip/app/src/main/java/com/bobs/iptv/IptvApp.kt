@file:OptIn(UnstableApi::class, ExperimentalFoundationApi::class)

package com.bobs.iptv

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

private val BgColor = Color(0xFF0E1116)
private val PanelColor = Color(0xFF161B22)
private val ChipColor = Color(0xFF21262D)
private val SelectedColor = Color(0xFF1F2A3A)
private val AccentColor = Color(0xFF2F81F7)
private val Muted = Color(0xFF8B949E)

private fun buildPlayer(context: Context): ExoPlayer {
    val http = DefaultHttpDataSource.Factory()
        .setAllowCrossProtocolRedirects(true)
        .setConnectTimeoutMs(15_000)
        .setReadTimeoutMs(15_000)
        .setUserAgent("Mozilla/5.0 (Linux; Android TV) BobsIPTV/0.1")
    return ExoPlayer.Builder(context)
        .setMediaSourceFactory(DefaultMediaSourceFactory(context).setDataSourceFactory(http))
        .build()
}

private fun Player.playUrl(url: String, forceHls: Boolean) {
    val item = MediaItem.Builder().setUri(url)
    if (forceHls || url.contains(".m3u8", ignoreCase = true)) {
        item.setMimeType(MimeTypes.APPLICATION_M3U8)
    }
    setMediaItem(item.build())
    prepare()
    playWhenReady = true
}

@Composable
fun IptvApp(vm: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val exo = remember { buildPlayer(context) }
    var buffering by remember { mutableStateOf(false) }
    var playbackError by remember { mutableStateOf<String?>(null) }
    var showInfo by remember { mutableStateOf(false) }
    var infoTick by remember { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }
    val triedHls = remember { booleanArrayOf(false) }

    // Player lifecycle + listener
    DisposableEffect(exo) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) playbackError = null
            }

            override fun onPlayerError(error: PlaybackException) {
                val url = vm.current?.url
                val formatProblem =
                    error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
                        error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED
                if (url != null && formatProblem && !triedHls[0]) {
                    // Many IPTV URLs are HLS without a ".m3u8" extension: retry once as HLS.
                    triedHls[0] = true
                    exo.playUrl(url, forceHls = true)
                } else {
                    playbackError = "Stream unavailable (${error.errorCodeName})"
                }
            }
        }
        exo.addListener(listener)
        onDispose {
            exo.removeListener(listener)
            exo.release()
        }
    }

    // Pause when the app goes to the background
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_STOP -> exo.pause()
                Lifecycle.Event.ON_START -> exo.play()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Start playing whenever the selected channel changes
    LaunchedEffect(vm.current?.url) {
        val ch = vm.current ?: return@LaunchedEffect
        playbackError = null
        triedHls[0] = false
        exo.playUrl(ch.url, forceHls = false)
        infoTick++
    }

    // Channel-info banner timer (shown in fullscreen)
    LaunchedEffect(infoTick) {
        showInfo = true
        delay(3500)
        showInfo = false
    }

    BackHandler(enabled = vm.fullscreen) { vm.fullscreen = false }

    Box(Modifier.fillMaxSize().background(BgColor)) {
        BrowseScreen(vm, onOpenSettings = { showSettings = true })

        // One player view, resized between preview and fullscreen so playback never restarts.
        val playerModifier = if (vm.fullscreen) {
            Modifier.fillMaxSize()
        } else {
            Modifier
                .align(Alignment.TopEnd)
                .padding(top = 24.dp, end = 24.dp)
                .fillMaxWidth(0.56f)
                .aspectRatio(16f / 9f)
        }
        Box(playerModifier.background(Color.Black)) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        useController = false
                        player = exo
                    }
                },
                modifier = Modifier.fillMaxSize(),
            )
            if (buffering) {
                CircularProgressIndicator(Modifier.align(Alignment.Center))
            }
            val err = playbackError
            if (err != null) {
                Text(
                    err,
                    color = Color.White,
                    modifier = Modifier.align(Alignment.Center).padding(16.dp),
                    textAlign = TextAlign.Center,
                )
            } else if (vm.current == null && !buffering) {
                Text(
                    "Select a channel",
                    color = Muted,
                    modifier = Modifier.align(Alignment.Center),
                )
            }
        }

        // Selected-channel details under the preview (non-fullscreen)
        if (!vm.fullscreen) {
            val ch = vm.current
            if (ch != null) {
                Column(
                    Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 24.dp, top = 120.dp)
                        .fillMaxWidth(0.56f)
                ) {
                    Text(ch.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text(ch.group, color = Muted, fontSize = 14.sp)
                }
            }
        }

        // Fullscreen: capture the remote for channel zapping
        if (vm.fullscreen) {
            val fr = remember { FocusRequester() }
            Box(
                Modifier
                    .fillMaxSize()
                    .onKeyEvent { ev ->
                        if (ev.type != KeyEventType.KeyDown) {
                            false
                        } else {
                            when (ev.key) {
                                Key.DirectionUp, Key.ChannelUp -> { vm.zap(-1); true }
                                Key.DirectionDown, Key.ChannelDown -> { vm.zap(1); true }
                                Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> { infoTick++; true }
                                Key.DirectionLeft, Key.DirectionRight -> true
                                else -> false
                            }
                        }
                    }
                    .focusRequester(fr)
                    .focusable()
            )
            LaunchedEffect(Unit) { fr.requestFocus() }

            if (showInfo) {
                val ch = vm.current
                if (ch != null) {
                    Column(
                        Modifier
                            .align(Alignment.BottomStart)
                            .fillMaxWidth()
                            .background(Color(0xCC000000))
                            .padding(horizontal = 32.dp, vertical = 20.dp)
                    ) {
                        Text(ch.name, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Text(ch.group + "   •   ▲▼ change channel   •   Back to exit", color = Muted, fontSize = 14.sp)
                    }
                }
            }
        }
    }

    if (showSettings) {
        SettingsDialog(
            current = vm.playlistUrl,
            onSave = { vm.setPlaylist(it); showSettings = false },
            onDismiss = { showSettings = false },
        )
    }
}

@Composable
private fun BrowseScreen(vm: MainViewModel, onOpenSettings: () -> Unit) {
    val listState = rememberLazyListState()
    val listFocus = remember { FocusRequester() }
    val visible = vm.visible

    // When returning from fullscreen (or after loading), jump to and focus the playing channel
    LaunchedEffect(vm.fullscreen, vm.channels.isNotEmpty()) {
        if (!vm.fullscreen) {
            val idx = visible.indexOfFirst { it.url == vm.current?.url }
            if (idx >= 0) {
                listState.scrollToItem(idx)
                delay(120)
                runCatching { listFocus.requestFocus() }
            }
        }
    }

    Column(
        Modifier
            .fillMaxHeight()
            .fillMaxWidth(0.4f)
            .background(PanelColor)
            .padding(12.dp)
    ) {
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 8.dp),
        ) {
            items(vm.categories) { cat ->
                Chip(cat, selected = cat == vm.category) { vm.category = cat }
            }
            item { Chip("⚙", selected = false) { onOpenSettings() } }
        }

        val err = vm.error
        when {
            vm.loading -> Centered("Loading playlist…")
            err != null && vm.channels.isEmpty() -> {
                Centered(err)
            }
            visible.isEmpty() -> Centered(
                if (vm.category == CAT_FAV) "No favorites yet.\nHold OK on a channel to add one." else "No channels here."
            )
            else -> LazyColumn(state = listState, modifier = Modifier.weight(1f)) {
                items(visible, key = { it.url }) { ch ->
                    val selected = ch.url == vm.current?.url
                    ChannelRow(
                        ch = ch,
                        selected = selected,
                        fav = ch.url in vm.favorites,
                        focusRequester = if (selected) listFocus else null,
                        onClick = {
                            if (selected) vm.fullscreen = true else vm.play(ch)
                        },
                        onFav = { vm.toggleFavorite(ch) },
                    )
                }
            }
        }

        Text(
            "OK: play / fullscreen    Hold OK or Menu: favorite",
            color = Muted,
            fontSize = 11.sp,
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}

@Composable
private fun ColumnScope.Centered(text: String) {
    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
        Text(text, color = Muted, textAlign = TextAlign.Center, modifier = Modifier.padding(16.dp))
    }
}

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(50))
            .background(
                when {
                    focused -> AccentColor
                    selected -> SelectedColor
                    else -> ChipColor
                }
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            label,
            color = Color.White,
            fontSize = 14.sp,
            maxLines = 1,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

@Composable
private fun ChannelRow(
    ch: Channel,
    selected: Boolean,
    fav: Boolean,
    focusRequester: FocusRequester?,
    onClick: () -> Unit,
    onFav: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clip(RoundedCornerShape(10.dp))
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .onFocusChanged { focused = it.isFocused }
            .onKeyEvent { ev ->
                if (ev.type == KeyEventType.KeyUp && ev.key == Key.Menu) {
                    onFav()
                    true
                } else {
                    false
                }
            }
            .background(
                when {
                    focused -> AccentColor
                    selected -> SelectedColor
                    else -> Color.Transparent
                }
            )
            .combinedClickable(onClick = onClick, onLongClick = onFav)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AsyncImage(
            model = ch.logo,
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(BgColor),
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(ch.name, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(ch.group, color = if (focused) Color.White else Muted, fontSize = 12.sp, maxLines = 1)
        }
        if (fav) Text("★", color = Color(0xFFFFC107), fontSize = 18.sp)
        if (selected) Text("  ▶", color = Color.White, fontSize = 14.sp)
    }
}

@Composable
private fun SettingsDialog(current: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(current) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Playlist URL") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                label = { Text("M3U / M3U8 URL") },
            )
        },
        confirmButton = { TextButton(onClick = { onSave(text.trim()) }) { Text("Save") } },
        dismissButton = {
            Row {
                TextButton(onClick = { text = DEFAULT_PLAYLIST }) { Text("Reset") }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        },
    )
}
