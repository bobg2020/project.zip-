package com.bobs.iptv

object M3uParser {
    private val attrRegex = Regex("""([\w-]+)="([^"]*)"""")

    fun parse(text: String): List<Channel> {
        val out = ArrayList<Channel>()
        var name: String? = null
        var logo: String? = null
        var group = "Other"

        for (raw in text.lineSequence()) {
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF") -> {
                    val attrs = attrRegex.findAll(line).associate {
                        it.groupValues[1].lowercase() to it.groupValues[2]
                    }
                    val title = line.substringAfterLast('"', line).substringAfter(",", "").trim()
                    name = title.ifEmpty { attrs["tvg-name"].orEmpty().ifEmpty { "Unknown" } }
                    logo = attrs["tvg-logo"]?.takeIf { it.isNotBlank() }
                    group = attrs["group-title"]
                        ?.split(";")
                        ?.firstOrNull()
                        ?.trim()
                        ?.takeIf { it.isNotEmpty() }
                        ?: "Other"
                }
                line.isEmpty() || line.startsWith("#") -> Unit
                else -> {
                    val n = name
                    if (n != null) {
                        out += Channel(n, line, logo, group)
                        name = null
                        logo = null
                        group = "Other"
                    }
                }
            }
        }
        return out.distinctBy { it.url }
    }
}
