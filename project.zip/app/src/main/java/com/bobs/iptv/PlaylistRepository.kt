package com.bobs.iptv

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object PlaylistRepository {
    /** Downloads and parses an M3U playlist. Falls back to the last cached copy if offline. */
    suspend fun load(context: Context, url: String): List<Channel> = withContext(Dispatchers.IO) {
        val cache = File(context.cacheDir, "playlist_${url.hashCode()}.m3u")
        try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 30_000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "BobsIPTV/0.1")
            }
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val parsed = M3uParser.parse(text)
            if (parsed.isNotEmpty()) cache.writeText(text)
            parsed
        } catch (e: Exception) {
            if (cache.exists()) M3uParser.parse(cache.readText()) else throw e
        }
    }
}
