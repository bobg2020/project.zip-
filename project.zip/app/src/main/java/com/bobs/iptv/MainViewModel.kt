package com.bobs.iptv

import android.app.Application
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

const val CAT_ALL = "All"
const val CAT_FAV = "★ Favorites"
private val PREFERRED = listOf("News", "Sports", "Movies", "Kids")

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)

    var channels by mutableStateOf<List<Channel>>(emptyList())
        private set
    var loading by mutableStateOf(true)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var category by mutableStateOf(CAT_ALL)
    var favorites by mutableStateOf(prefs.favorites)
        private set
    var current by mutableStateOf<Channel?>(null)
        private set
    var playlistUrl by mutableStateOf(prefs.playlistUrl)
        private set
    var fullscreen by mutableStateOf(false)

    val categories: List<String> by derivedStateOf {
        val groups = channels.map { it.group }.distinct()
        val preferred = PREFERRED.filter { it in groups }
        val rest = groups.filter { it !in PREFERRED }.sorted()
        listOf(CAT_FAV, CAT_ALL) + preferred + rest
    }

    val visible: List<Channel> by derivedStateOf {
        when (category) {
            CAT_ALL -> channels
            CAT_FAV -> channels.filter { it.url in favorites }
            else -> channels.filter { it.group == category }
        }
    }

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            loading = true
            error = null
            try {
                val list = PlaylistRepository.load(getApplication(), playlistUrl)
                channels = list
                if (current == null) {
                    val last = prefs.lastChannel
                    current = list.firstOrNull { it.url == last }
                }
                if (list.isEmpty()) error = "That playlist has no channels."
            } catch (e: Exception) {
                error = "Couldn't load playlist: ${e.message}"
            }
            loading = false
        }
    }

    fun setPlaylist(url: String) {
        if (url.isBlank()) return
        prefs.playlistUrl = url
        playlistUrl = url
        current = null
        category = CAT_ALL
        load()
    }

    fun play(ch: Channel) {
        current = ch
        prefs.lastChannel = ch.url
    }

    /** Move to the next (+1) or previous (-1) channel in the visible list, wrapping around. */
    fun zap(delta: Int) {
        val list = visible
        if (list.isEmpty()) return
        val i = list.indexOfFirst { it.url == current?.url }
        val next = if (i < 0) 0 else (i + delta + list.size) % list.size
        play(list[next])
    }

    fun toggleFavorite(ch: Channel) {
        val s = favorites.toMutableSet()
        if (!s.add(ch.url)) s.remove(ch.url)
        favorites = s
        prefs.favorites = s
    }
}
